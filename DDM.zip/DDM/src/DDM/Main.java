package DDM;



import DDM.dice.Dice;
import DDM.figures.CrossFigure;
import DDM.figures.Figure;
import DDM.figures.Tfigure;
import DDM.figures.Zfigure;

public class Main {

	public static void main(String[] args) 
	{
		Board b = new Board(9, 9);
		Zfigure zf = new Zfigure();		
		CrossFigure crossFigure = new CrossFigure();
		Tfigure tf = new Tfigure();
		
		b.setStartPos();
		
		for(int h =0;h<b.getHeight();h++)
		{
			for(int w=0;w<b.getWidth();w++)
			{
				System.out.print(b.getCellAt(w, h).isEmpty());
				System.out.print(w+","+h+" ");
			}
			System.out.println();
		}
		
		
		
		System.out.println();
		System.out.println("----------------------------------");
		System.out.println();
		
		zf.expand(b, b.getCellAt(4, 3));
		zf.expand(b, b.getCellAt(4, 4)); //-> not touching already built path            
		zf.expand(b, b.getCellAt(4, 2)); //-> not all expansion cells are empty			  
		crossFigure.expand(b,b.getCellAt(5, 5));
		tf.expand(b, b.getCellAt(4, 8));
		
		for(int h =0;h<b.getHeight();h++)                  
		{
			for(int w=0;w<b.getWidth();w++)
			{
				System.out.print(b.getCellAt(w, h).isEmpty());
				System.out.print(w+","+h+" ");
			}
			System.out.println();
		}
		
		Dice d1 = new Dice(1);
		Dice d2 = new Dice(2);
		Dice d3 = new Dice(3);
		Dice d4 = new Dice(4);
		Dice itd;
		for(int j=1;j<5;j++)
		{	
			switch(j)
			{
				case 1 : 
				{
					itd = d1;
					System.out.println("Dice one");
					break;
				}
				case 2 : 
				{
					System.out.println();
					itd = d2;
					System.out.println("Dice two");
					break;
				}
				case 3 : 
				{
					System.out.println();
					itd = d3;
					System.out.println("Dice three");
					break;
				}
				case 4 : 
				{
					System.out.println();
					itd = d4;
					System.out.println("Dice four");
					break;
					
				}
				default : 
				{
					System.out.println("Default");
					itd = d1;
				}
			}
				for(int i=1;i<7;i++)
				{
					System.out.println("Side " + i + ":"+ itd.getAmount(i) +"x "+ itd.getFace(i));
				}
			
		}
//		Dice d = new DiceLevelOne();
//		Figure f = d.transorm(crossFigure);
//		System.out.println(f.getClass());
		
	}
	
}
