package DDM.dice;

import java.util.Random;

import DDM.figures.Figure;

public class Dice  
{
	
	public int row()
	{
		Random rand = new Random();		
		
		return rand.nextInt(6)+1;		
	}	
	
	public Figure transorm(Figure f)
	{
		return f;
	}
	
	private String[] face = new String [7];
	private int[] amount = new int[7];
	private int[] side = new int [7];

	public Dice(int level)
	{
		int creatures;
		if(level == 1)
		{
			creatures = 5;
		}
		else if(level == 2)
		{
			creatures = 4;
		}
		else if(level == 3)
		{
			creatures = 3;
		}
		else if(level == 4)
		{
			creatures = 2;
		}
		else 
		{
			creatures = 0;
			System.out.println("No such dice level");
		}
		
		for(int i=1;i<creatures;i++)
		{
			this.side[i]=i;
			this.face[i] = "Creature";
			this.amount[i] = 1;
		}
		
		for(int i=creatures;i<7;i++)
		{
			this.side[i]=i;
			Random rand = new Random();
			int r = rand.nextInt(3)+1;
			if (r==1)
			{
				this.face[i] = "Move";
				this.amount[i] = rand.nextInt(5)+1;
			}
			else if(r==2)
			{
				this.face[i] = "Attack";
				this.amount[i] = rand.nextInt(5)+1;
			}
			else
			{
				this.face[i] = "Block";
				this.amount[i] = rand.nextInt(5)+1;
			}
		}
	}

	public String getFace(int side) 
	{
		return face[side];
	}

	public int getAmount(int side)
	{
		return amount[side];
	}

	public int getSide(int side_) 
	{
		return side[side_];
	}
	
	
	
}
