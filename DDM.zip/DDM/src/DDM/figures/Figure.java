package DDM.figures;

import DDM.Board;
import DDM.Cell;

public abstract class Figure {

	//private abstract boolean canExpand(Board b,Cell center);
	public abstract void expand(Board b,Cell center);
	
	//protected abstract boolean expandOnEmpty(Board b,Cell center);
	
	
}
