package DDM.figures;

import DDM.Board;
import DDM.Cell;

public class Zfigure extends Figure {

	
	private boolean canExpand(Board b,Cell center) {
		
		if(!expandOnEmpty(b, center))
		{
			System.out.println("Not All Expansion Cells Are Empty!");
			return false;
		}
		if(!canPatch(b,center))
		{
			System.out.println("Not Touching Already Built Road");
			return false;
		}				
			return true;		
	}

	private boolean canPatch(Board b, Cell center) 
	{
		return( !b.getCellAt(center.getX()-2,center.getY()+1).isEmpty() ||
				!b.getCellAt(center.getX()-1,center.getY()).isEmpty() ||
				!b.getCellAt(center.getX()-1,center.getY()-1).isEmpty() ||
				!b.getCellAt(center.getX()-1,center.getY()-2).isEmpty() ||
				!b.getCellAt(center.getX(),center.getY()-3).isEmpty() ||
				!b.getCellAt(center.getX()+1,center.getY()-3).isEmpty() ||
				!b.getCellAt(center.getX()+2,center.getY()-2).isEmpty() ||
				!b.getCellAt(center.getX()+1,center.getY()-1).isEmpty() ||
				!b.getCellAt(center.getX()+1,center.getY()).isEmpty() ||
				!b.getCellAt(center.getX()+1,center.getY()+1).isEmpty() ||
				!b.getCellAt(center.getX(),center.getY()+2).isEmpty() ||
				!b.getCellAt(center.getX()-1,center.getY()+2).isEmpty() );
			 
		
				
		
	}

	
	private boolean expandOnEmpty(Board b, Cell center)
	{
		return b.getCellAt(center.getX()-1,center.getY()+1).isEmpty() &&
				b.getCellAt(center.getX(),center.getY()+1).isEmpty() &&
				b.getCellAt(center.getX(),center.getY()).isEmpty() &&
				b.getCellAt(center.getX(),center.getY()-1).isEmpty() &&
				b.getCellAt(center.getX(),center.getY()-2).isEmpty() &&
				b.getCellAt(center.getX()+1,center.getY()-2).isEmpty();
	}

	@Override
	public void expand(Board b, Cell center) {
		if(canExpand(b,center))
		{
			b.getCellAt(center.getX()-1,center.getY()+1).setEmpty(false); 
			b.getCellAt(center.getX(),center.getY()+1).setEmpty(false);
			b.getCellAt(center.getX(),center.getY()).setEmpty(false); 
			b.getCellAt(center.getX(),center.getY()-1).setEmpty(false); 
			b.getCellAt(center.getX(),center.getY()-2).setEmpty(false); 
			b.getCellAt(center.getX()+1,center.getY()-2).setEmpty(false);	
		}
		
		
	}

	

	
	
}
