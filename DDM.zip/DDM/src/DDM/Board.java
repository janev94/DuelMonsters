package DDM;

import java.util.ArrayList;
import java.util.List;

public class Board {
	List<Cell> b = new ArrayList<Cell>();
	
	private int width;
	private int height;
		
	Board(int width,int height)
	{
		this.width=width;
		this.height=height;
		for(int h=0;h<height;h++)
		{
			for(int w=0;w<width;w++)
			{
				Cell c = new Cell(w,h);
				boolean add = b.add(c);
				if(!add)
				{
					System.out.println("aaa");
				}
				
			}						 
									  
		}
	}
	
	public int getWidth()
	{
		return this.width;
	}
	
	public int getHeight()
	{
		return this.height;
	}
	
	public Cell getCellAt(int w, int h)
	{
		Cell cell = null;
		
		if (w > width || w < 0 || h > height || h < 0)
		{
			System.out.println("out of bounds");
		}
		else cell = b.get(w + h*height);
		return cell;
	}
	
	public void setStartPos()
	{
		this.getCellAt(width/2,0).setEmpty(false);
		this.getCellAt(width/2,height-1).setEmpty(false);
	}
	
}
